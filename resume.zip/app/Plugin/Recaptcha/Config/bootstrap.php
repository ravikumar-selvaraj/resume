<?php

Configure::write('Recaptcha.publicKey', '6LfDCMsSAAAAANafm_TCMjDPrq7Z_4GU9j6Xt2z_');
Configure::write('Recaptcha.privateKey', '6LfDCMsSAAAAAMjzs7gTMXmONcDnt41D5270TuHB');
?>
