<?php
App::uses('AppModel', 'Model');
/**
 * Tag Model
 *
 */
class Tag extends AppModel {

/**
 * Primary key field
 *
 * @var string
 */
	public $primaryKey = 'tid';

}
