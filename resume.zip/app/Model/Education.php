<?php
App::uses('AppModel', 'Model');
/**
 * User Model
 *
 */
class Education extends AppModel {

/**
 * Primary key field
 *
 * @var string
 */
	public $primaryKey = 'eid';

}
