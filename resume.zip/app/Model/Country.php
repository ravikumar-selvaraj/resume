<?php
App::uses('AppModel', 'Model');
/**
 * User Model
 *
 */
class Country extends AppModel {

/**
 * Primary key field
 *
 * @var string
 */
	public $primaryKey = 'country_id';

}
