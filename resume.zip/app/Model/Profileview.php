<?php
App::uses('AppModel', 'Model');
/**
 * User Model
 *
 */
class Profileview  extends AppModel {

/**
 * Primary key field
 *
 * @var string
 */
	public $primaryKey = 'pvid';

}
