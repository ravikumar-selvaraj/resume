<?php
App::uses('AppModel', 'Model');
/**
 * User Model
 *
 */
class Recomment  extends AppModel {

/**
 * Primary key field
 *
 * @var string
 */
 public $name = 'recommends';
	public $primaryKey = 'recid';

}
