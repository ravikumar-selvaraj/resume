<?php
App::uses('AppModel', 'Model');
/**
 * User Model
 *
 */
class Portaudio extends AppModel {

/**
 * Primary key field
 *
 * @var string
 */
	public $primaryKey = 'paid';

}
