<?php
App::uses('AppModel', 'Model');
/**
 * User Model
 *
 */
class Portfolio extends AppModel {

/**
 * Primary key field
 *
 * @var string
 */
	public $primaryKey = 'pid';

}
