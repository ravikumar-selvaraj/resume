<?php
App::uses('AppModel', 'Model');
/**
 * Tag Model
 *
 */
class Userdashboard extends AppModel {

/**
 * Primary key field
 *
 * @var string
 */
	public $primaryKey = 'udid';

}
