<?php
App::uses('AppModel', 'Model');
/**
 * Tip Model
 *
 */
class Tip extends AppModel {

/**
 * Primary key field
 *
 * @var string
 */
	public $primaryKey = 'tid';

}
