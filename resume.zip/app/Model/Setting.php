<?php
App::uses('AppModel', 'Model');
/**
 * Setting Model
 *
 */
class Setting extends AppModel {

/**
 * Primary key field
 *
 * @var string
 */
	public $primaryKey = 'sid';

/**
 * Display field
 *
 * @var string
 */
	public $displayField = 'sid';

}
