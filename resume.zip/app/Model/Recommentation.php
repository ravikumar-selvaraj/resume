<?php
App::uses('AppModel', 'Model');
/**
 * User Model
 *
 */
class Recommentation  extends AppModel {

/**
 * Primary key field
 *
 * @var string
 */
    public $name = 'recommendations';
	public $primaryKey = 'rid';

}
