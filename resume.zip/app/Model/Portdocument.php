<?php
App::uses('AppModel', 'Model');
/**
 * User Model
 *
 */
class Portdocument extends AppModel {

/**
 * Primary key field
 *
 * @var string
 */
	public $primaryKey = 'pdid';

}
